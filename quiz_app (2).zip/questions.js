// Define categories and questions
const QUESTION_BANK = {
  'Web Development': [
    {
      q: 'What does HTML stand for?',
      options: ['HyperText Markup Language','HighText Machine Language','Hyperlinks and Text Markup Language','Home Tool Markup Language'],
      answer: 0
    },
    {
      q: 'Which HTML tag is used to include JavaScript?',
      options: ['<js>','<javascript>','<script>','<code>'],
      answer: 2
    },
    {
      q: 'Which CSS property controls text size?',
      options: ['font-weight','font-size','text-style','text-size'],
      answer: 1
    },
    {
      q: 'Which method adds an item to the end of a JavaScript array?',
      options: ['push()','pop()','shift()','unshift()'],
      answer: 0
    },
    {
      q: 'Which HTTP status code means “Not Found”?',
      options: ['200','301','404','500'],
      answer: 2
    }
  ],
  'General Knowledge': [
    {
      q: 'Which planet is known as the Red Planet?',
      options: ['Earth','Mars','Jupiter','Venus'],
      answer: 1
    },
    {
      q: 'Who wrote the national anthem of India?',
      options: ['Rabindranath Tagore','Bankim Chandra Chatterjee','Sarojini Naidu','Aurobindo Ghosh'],
      answer: 0
    },
    {
      q: 'How many continents are there?',
      options: ['5','6','7','8'],
      answer: 2
    },
    {
      q: 'What is the capital of Karnataka?',
      options: ['Mysuru','Mangaluru','Bengaluru','Hubballi'],
      answer: 2
    },
    {
      q: 'Which is the largest ocean on Earth?',
      options: ['Indian Ocean','Atlantic Ocean','Arctic Ocean','Pacific Ocean'],
      answer: 3
    }
  ],
  'Science': [
    {
      q: 'Water boils at what temperature at sea level?',
      options: ['50°C','100°C','150°C','212°C'],
      answer: 1
    },
    {
      q: 'What gas do plants absorb from the atmosphere?',
      options: ['Oxygen','Carbon dioxide','Nitrogen','Hydrogen'],
      answer: 1
    },
    {
      q: 'The unit of electric current is:',
      options: ['Volt','Watt','Ampere','Ohm'],
      answer: 2
    },
    {
      q: 'Which vitamin is produced in skin when exposed to sunlight?',
      options: ['Vitamin A','Vitamin B12','Vitamin C','Vitamin D'],
      answer: 3
    },
    {
      q: 'Which device measures atmospheric pressure?',
      options: ['Thermometer','Barometer','Hygrometer','Anemometer'],
      answer: 1
    }
  ]
};