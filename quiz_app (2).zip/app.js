// Helpers
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));
const fmt2 = (n) => n.toString().padStart(2,'0');

// Views
const views = {
  home: $('#view-home'),
  quiz: $('#view-quiz'),
  result: $('#view-result'),
  leaderboard: $('#view-leaderboard'),
  about: $('#view-about')
};

function showView(name){
  Object.values(views).forEach(v => v.classList.remove('active'));
  views[name].classList.add('active');
}

// Populate categories
const selectCategory = $('#select-category');
const inputCount = $('#input-count');
const inputTimer = $('#input-timer');
const inputName = $('#input-name');
const lbCategory = $('#lb-category');

function loadCategories(){
  const cats = Object.keys(QUESTION_BANK);
  selectCategory.innerHTML = cats.map(c => `<option value="${c}">${c}</option>`).join('');
  lbCategory.innerHTML = selectCategory.innerHTML;
}
loadCategories();

// Navigation
$('#nav-home').onclick = () => showView('home');
$('#nav-leaderboard').onclick = () => { loadLeaderboard(); showView('leaderboard'); };
$('#nav-about').onclick = () => showView('about');

// Quiz state
let state = {
  name: '',
  category: '',
  questions: [],
  idx: 0,
  score: 0,
  timer: 0,
  left: 0,
  selection: null,
  answers: [] // {q, chosen, correctIndex, isCorrect}
};

// Start quiz
$('#btn-start').onclick = () => {
  const name = inputName.value.trim() || 'Player';
  const category = selectCategory.value;
  const count = Math.min(Math.max(parseInt(inputCount.value||'5',10),3),20);
  const perSec = Math.min(Math.max(parseInt(inputTimer.value||'15',10),5),120);

  // Prepare question set
  const pool = QUESTION_BANK[category].slice();
  // Shuffle
  for(let i=pool.length-1;i>0;i--){
    const j = Math.floor(Math.random()*(i+1));
    [pool[i],pool[j]] = [pool[j],pool[i]];
  }
  const qs = pool.slice(0, Math.min(count, pool.length));

  state = { name, category, questions: qs, idx: 0, score: 0, timer: null, left: perSec, selection: null, answers: [] };

  $('#meta-category').textContent = category;
  startQuestion();
  showView('quiz');
};

function startQuestion(){
  const qpos = `${state.idx+1}/${state.questions.length}`;
  $('#meta-qpos').textContent = qpos;
  $('#progress-bar').style.width = ((state.idx)/state.questions.length*100) + '%';

  const q = state.questions[state.idx];
  $('#question-text').textContent = q.q;
  const ans = $('#answers');
  ans.innerHTML = '';
  q.options.forEach((opt,i)=>{
    const div = document.createElement('button');
    div.className = 'answer';
    div.textContent = opt;
    div.onclick = () => selectAnswer(i, div);
    ans.appendChild(div);
  });

  state.selection = null;
  $('#btn-submit').disabled = false;
  $('#btn-next').disabled = true;

  // Timer
  state.left = state.left || 15;
  state.left = parseInt($('#input-timer').value||state.left,10);
  $('#meta-timer').textContent = fmt2(state.left);
  if(state.timer) clearInterval(state.timer);
  state.timer = setInterval(()=>{
    state.left--;
    $('#meta-timer').textContent = fmt2(state.left);
    if(state.left<=0){
      clearInterval(state.timer);
      lockQuestion(true);
    }
  },1000);
}

function selectAnswer(i, node){
  $$('.answer').forEach(n => n.classList.remove('selected'));
  node.classList.add('selected');
  state.selection = i;
}

$('#btn-submit').onclick = () => {
  lockQuestion(false);
};

function lockQuestion(timeout=false){
  $('#btn-submit').disabled = true;
  $('#btn-next').disabled = false;
  if(state.timer) clearInterval(state.timer);

  const q = state.questions[state.idx];
  const chosen = (state.selection==null) ? -1 : state.selection;
  const isCorrect = chosen === q.answer;

  // decorate
  $$('.answer').forEach((n, i)=>{
    if(i === q.answer) n.classList.add('correct');
    if(i === chosen && i !== q.answer) n.classList.add('wrong');
    n.disabled = true;
  });

  if(isCorrect) state.score++;

  state.answers.push({ q: q.q, chosen, correctIndex: q.answer, isCorrect, options: q.options.slice(), timeout });

  if(state.idx === state.questions.length-1){
    $('#btn-next').textContent = 'Finish';
  }else{
    $('#btn-next').textContent = 'Next';
  }
}

$('#btn-next').onclick = () => {
  if(state.idx < state.questions.length-1){
    state.idx++;
    startQuestion();
  }else{
    showResult();
  }
};

$('#btn-quit').onclick = () => {
  if(confirm('Quit the quiz? Your progress will be lost.')){
    showView('home');
  }
};

function showResult(){
  $('#progress-bar').style.width = '100%';
  const total = state.questions.length;
  const correct = state.score;
  const percent = Math.round((correct/total)*100);

  $('#result-summary').innerHTML = `
    <strong>${state.name}</strong>, you scored <strong>${correct}</strong> / <strong>${total}</strong> (<strong>${percent}%</strong>) in <em>${state.category}</em>.
  `;

  const container = $('#result-breakdown');
  container.innerHTML = '';
  state.answers.forEach((a, idx)=>{
    const el = document.createElement('div');
    el.className = 'card';
    const chosenText = a.chosen>=0 ? a.options[a.chosen] : '<i>no answer</i>';
    el.innerHTML = \`
      <div><strong>Q${idx+1}.</strong> \${a.q}</div>
      <div>Your answer: \${chosenText}</div>
      <div>Correct answer: <strong>\${a.options[a.correctIndex]}</strong></div>
    \`;
    container.appendChild(el);
  });

  saveLeaderboard(state.name, state.category, correct, total);
  showView('result');
}

$('#btn-retry').onclick = () => {
  // restart same settings
  $('#btn-start').click();
};
$('#btn-home').onclick = () => showView('home');
$('#btn-view-leaderboard').onclick = () => { loadLeaderboard(); showView('leaderboard'); };

// Leaderboard
const LB_KEY = 'quizapp_leaderboard_v1';

function getLeaderboard(){
  try{
    return JSON.parse(localStorage.getItem(LB_KEY)) || {};
  }catch(e){
    return {};
  }
}

function saveLeaderboard(name, category, score, total){
  const data = getLeaderboard();
  const entry = { name, score, total, date: new Date().toISOString() };
  if(!data[category]) data[category] = [];
  data[category].push(entry);
  // keep top 20 by score then date desc
  data[category].sort((a,b)=> (b.score - a.score) || (new Date(b.date)-new Date(a.date)));
  data[category] = data[category].slice(0,20);
  localStorage.setItem(LB_KEY, JSON.stringify(data));
}

function loadLeaderboard(){
  const cat = lbCategory.value || selectCategory.value;
  lbCategory.value = cat;
  const data = getLeaderboard();
  const rows = (data[cat] || []).map((e, i)=>{
    const d = new Date(e.date);
    const human = d.toLocaleString();
    return \`<tr><td>\${i+1}</td><td>\${e.name}</td><td>\${e.score}</td><td>\${e.total}</td><td>\${human}</td></tr>\`;
  }).join('');
  $('#lb-table tbody').innerHTML = rows || '<tr><td colspan="5">No scores yet. Play a quiz!</td></tr>';
}

lbCategory.onchange = loadLeaderboard;
$('#btn-clear-lb').onclick = () => {
  const cat = lbCategory.value;
  if(confirm('Clear leaderboard for "'+cat+'"?')){
    const data = getLeaderboard();
    data[cat] = [];
    localStorage.setItem(LB_KEY, JSON.stringify(data));
    loadLeaderboard();
  }
};

// Init
showView('home');
