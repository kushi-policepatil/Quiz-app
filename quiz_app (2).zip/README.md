# Quiz App (HTML/CSS/JS)

A lightweight quiz application you can run by double-clicking `index.html`. No server required.

## Features
- Multiple categories (Web Development, General Knowledge, Science)
- Configurable question count and time per question
- Timer, progress bar, per-question feedback
- Results breakdown
- Leaderboard stored in `localStorage` (per category)
- Responsive and works offline

## How to run
1. Unzip the folder.
2. Open `index.html` in your browser (Chrome/Edge/Firefox).
3. Pick a category, set your options, and click **Start Quiz**.

## Customize questions
Open `questions.js` and edit `QUESTION_BANK`. Add new categories or questions using the same format.

```js
'My Category': [
  { q: 'Question text?', options: ['A','B','C','D'], answer: 1 },
  // ...
]
```

## Notes
- Leaderboard is per-browser. Clearing site data will reset it.
- All code is vanilla JS; you can host it on any static server (GitHub Pages, Netlify, Vercel).
